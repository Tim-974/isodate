Ce fichier est uniquement là pour maintenir le dossier courant non vide.
Ce fichier peut-être supprimé dès que vous aurez écrit votre premier test.